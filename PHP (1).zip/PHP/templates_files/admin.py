from django.contrib import admin
from .models import *

admin.site.register(MainPage)
admin.site.register(Demand)
admin.site.register(Geography)
admin.site.register(Skills)
